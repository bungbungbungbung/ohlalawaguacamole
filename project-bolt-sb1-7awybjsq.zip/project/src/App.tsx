import React, { useState } from 'react';
import { Calculator, Trash2, PlusCircle, DollarSign } from 'lucide-react';

interface StockPurchase {
  shares: number;
  price: number;
  dividends: number;
  id: string;
}

function App() {
  const [purchases, setPurchases] = useState<StockPurchase[]>([
    { shares: 0, price: 0, dividends: 0, id: '1' }
  ]);
  const [includeDividends, setIncludeDividends] = useState(false);

  const addPurchase = () => {
    setPurchases([
      ...purchases,
      { shares: 0, price: 0, dividends: 0, id: crypto.randomUUID() }
    ]);
  };

  const removePurchase = (id: string) => {
    if (purchases.length > 1) {
      setPurchases(purchases.filter(purchase => purchase.id !== id));
    }
  };

  const updatePurchase = (id: string, field: 'shares' | 'price' | 'dividends', value: number) => {
    setPurchases(purchases.map(purchase => 
      purchase.id === id ? { ...purchase, [field]: value } : purchase
    ));
  };

  const calculateAverageCost = () => {
    const totalShares = purchases.reduce((sum, purchase) => sum + purchase.shares, 0);
    const totalCost = purchases.reduce((sum, purchase) => sum + (purchase.shares * purchase.price), 0);
    const totalDividends = includeDividends ? 
      purchases.reduce((sum, purchase) => sum + purchase.dividends, 0) : 0;
    
    return totalShares ? ((totalCost - totalDividends) / totalShares).toFixed(2) : '0.00';
  };

  const totalShares = purchases.reduce((sum, purchase) => sum + purchase.shares, 0);
  const totalCost = purchases.reduce((sum, purchase) => sum + (purchase.shares * purchase.price), 0);
  const totalDividends = purchases.reduce((sum, purchase) => sum + purchase.dividends, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center gap-3 mb-6">
            <Calculator className="w-8 h-8 text-indigo-600" />
            <h1 className="text-2xl font-bold text-gray-800">Stock Average Calculator</h1>
          </div>

          <div className="mb-6">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-600">
              <input
                type="checkbox"
                checked={includeDividends}
                onChange={(e) => setIncludeDividends(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500"
              />
              Include dividends in cost basis calculation
            </label>
          </div>

          <div className="space-y-4">
            {purchases.map((purchase, index) => (
              <div key={purchase.id} className="flex gap-4 items-start">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-600 mb-1">
                    Number of Shares
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={purchase.shares || ''}
                    onChange={(e) => updatePurchase(purchase.id, 'shares', +e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter number of shares"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-600 mb-1">
                    Price per Share ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={purchase.price || ''}
                    onChange={(e) => updatePurchase(purchase.id, 'price', +e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter price per share"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-600 mb-1">
                    Dividends Received ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={purchase.dividends || ''}
                    onChange={(e) => updatePurchase(purchase.id, 'dividends', +e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter dividends received"
                  />
                </div>
                <button
                  onClick={() => removePurchase(purchase.id)}
                  className="mt-6 p-2 text-red-600 hover:text-red-800 transition-colors"
                  disabled={purchases.length === 1}
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>

          <button
            onClick={addPurchase}
            className="mt-4 flex items-center gap-2 text-indigo-600 hover:text-indigo-800 transition-colors"
          >
            <PlusCircle className="w-5 h-5" />
            <span>Add Another Purchase</span>
          </button>

          <div className="mt-8 p-6 bg-gray-50 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-4 bg-white rounded-lg shadow">
                <h3 className="text-sm font-medium text-gray-500">Average Cost</h3>
                <p className="text-2xl font-bold text-indigo-600">${calculateAverageCost()}</p>
              </div>
              <div className="p-4 bg-white rounded-lg shadow">
                <h3 className="text-sm font-medium text-gray-500">Total Shares</h3>
                <p className="text-2xl font-bold text-indigo-600">{totalShares}</p>
              </div>
              <div className="p-4 bg-white rounded-lg shadow">
                <h3 className="text-sm font-medium text-gray-500">Total Cost</h3>
                <p className="text-2xl font-bold text-indigo-600">${totalCost.toFixed(2)}</p>
              </div>
              <div className="p-4 bg-white rounded-lg shadow">
                <h3 className="text-sm font-medium text-gray-500">Total Dividends</h3>
                <p className="text-2xl font-bold text-indigo-600">${totalDividends.toFixed(2)}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;